"""Marvel characters models package."""
